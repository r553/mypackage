#mypackage
This library was created for recursive functions and sorting functions


#building this package locally
python setup.py sdist

#installing this package from GitHub
pip install git+https://github.com/r553/example-python-package.git

#updating this package from GitHub
pip install --upgrade git+https://github.com/r553/example-python-package.git
